package com.hamrahsarmaye.app

/** Asset-specific valuation primitives. These calculate reference values only; they never emit buy/sell signals. */
enum class ValuationKind {
    GOLD_18K_GRAM, MELTED_GOLD_GRAM, GOLD_COIN, SILVER_GRAM, PLATINUM_GRAM,
    FX_CROSS_RATE, INDUSTRIAL_METAL, OIL_BARREL, STOCK_EARNINGS,
    VEHICLE_COMPARABLE, PROPERTY_COMPARABLE
}

data class ValuationResult(
    val kind: ValuationKind,
    val theoreticalLocalValue: Double?,
    val unit: String,
    val inputsComplete: Boolean,
    val explanation: String
)

object AssetValuationCore {
    const val TROY_OUNCE_GRAMS = 31.1034768
    const val GOLD_18_PURITY = 0.75
    const val GOLD_18_FACTOR = TROY_OUNCE_GRAMS / GOLD_18_PURITY

    private fun valid(vararg values: Double): Boolean = values.all { it.isFinite() && it > 0.0 }
    private fun result(kind: ValuationKind, value: Double?, unit: String, explanation: String) =
        ValuationResult(kind, value?.takeIf { it.isFinite() && it > 0.0 }, unit,
            value != null && value.isFinite() && value > 0.0, explanation)

    /** Spot is USD per troy ounce; FX is domestic currency per USD. */
    fun gold18Gram(spotUsdPerOz: Double, domesticFxPerUsd: Double) =
        result(ValuationKind.GOLD_18K_GRAM,
            if (valid(spotUsdPerOz, domesticFxPerUsd)) spotUsdPerOz * domesticFxPerUsd / GOLD_18_FACTOR else null,
            "local currency / gram", "اونس طلای جهانی × نرخ ارز داخلی ÷ ۴۱٫۴۷۱۳")

    /** Purity is expressed as parts per thousand, e.g. 995; quote is USD per troy ounce. */
    fun meltedGoldGram(spotUsdPerOz: Double, domesticFxPerUsd: Double, purityPerThousand: Double) =
        result(ValuationKind.MELTED_GOLD_GRAM,
            if (valid(spotUsdPerOz, domesticFxPerUsd, purityPerThousand) && purityPerThousand <= 1000.0)
                spotUsdPerOz * domesticFxPerUsd / TROY_OUNCE_GRAMS * (purityPerThousand / 1000.0) else null,
            "local currency / gram", "اونس جهانی × ارز داخلی ÷ گرم هر اونس × عیار/۱۰۰۰؛ بدون اجرت و کسورات")

    /** Fine-gold weight is grams; premium is a signed percentage relative to metal value. */
    fun goldCoin(spotUsdPerOz: Double, domesticFxPerUsd: Double, fineGoldGrams: Double, premiumPercent: Double) =
        result(ValuationKind.GOLD_COIN,
            if (valid(spotUsdPerOz, domesticFxPerUsd, fineGoldGrams) && premiumPercent.isFinite() && premiumPercent > -100.0)
                (spotUsdPerOz * domesticFxPerUsd / TROY_OUNCE_GRAMS * fineGoldGrams) * (1.0 + premiumPercent / 100.0) else null,
            "local currency / coin", "ارزش طلای خالص بر اساس وزن و عیار + حباب/صرف یا کسر بازار")

    /** Spot is USD per troy ounce; purity is a fraction from 0 to 1. */
    fun preciousMetalGram(kind: ValuationKind, spotUsdPerOz: Double, domesticFxPerUsd: Double, purity: Double): ValuationResult {
        require(kind == ValuationKind.SILVER_GRAM || kind == ValuationKind.PLATINUM_GRAM)
        val value = if (valid(spotUsdPerOz, domesticFxPerUsd, purity) && purity <= 1.0)
            spotUsdPerOz * domesticFxPerUsd / TROY_OUNCE_GRAMS * purity else null
        return result(kind, value, "local currency / gram", "قیمت اونس همان فلز × ارز داخلی ÷ ۳۱٫۱۰۳۴۷۶۸ × خلوص")
    }

    /** Cross conversion from two domestic rates quoted as local-currency units per 1 currency unit. */
    fun fxCrossRate(sourceToLocal: Double, targetToLocal: Double) =
        result(ValuationKind.FX_CROSS_RATE,
            if (valid(sourceToLocal, targetToLocal)) sourceToLocal / targetToLocal else null,
            "target currency / source currency", "نرخ خریدوفروش داخلی هر دو ارز؛ نرخ متقاطع = مبدأ به پول محلی ÷ مقصد به پول محلی")

    /** Commodity spot USD per metric tonne; output local currency per kilogram. */
    fun industrialMetalKg(spotUsdPerMetricTonne: Double, domesticFxPerUsd: Double) =
        result(ValuationKind.INDUSTRIAL_METAL,
            if (valid(spotUsdPerMetricTonne, domesticFxPerUsd)) spotUsdPerMetricTonne * domesticFxPerUsd / 1000.0 else null,
            "local currency / kg", "قیمت جهانی هر تن متریک × ارز داخلی ÷ ۱۰۰۰")

    /** Benchmark USD per barrel; output local currency per barrel. */
    fun oilBarrel(benchmarkUsdPerBarrel: Double, domesticFxPerUsd: Double) =
        result(ValuationKind.OIL_BARREL,
            if (valid(benchmarkUsdPerBarrel, domesticFxPerUsd)) benchmarkUsdPerBarrel * domesticFxPerUsd else null,
            "local currency / barrel", "شاخص مشخص نفت به دلار برای هر بشکه × نرخ ارز داخلی؛ نوع نفت/قرارداد باید یکسان باشد")

    /** EPS and P/E must be from the same reporting currency/period and positive. */
    fun stockEarningsPerShare(eps: Double, justifiedPe: Double) =
        result(ValuationKind.STOCK_EARNINGS,
            if (valid(eps, justifiedPe)) eps * justifiedPe else null,
            "reporting currency / share", "سود هر سهم معتبر × نسبت قیمت به سود توجیه‌پذیر؛ نیازمند بررسی کیفیت سود و بدهی")

    /** Median of genuinely comparable local sale prices, adjusted by a documented signed percentage. */
    fun vehicleComparable(medianComparablePrice: Double, adjustmentPercent: Double) =
        comparable(ValuationKind.VEHICLE_COMPARABLE, medianComparablePrice, adjustmentPercent,
            "local currency / vehicle", "میانه قیمت معاملات خودروهای هم‌مدل/تیپ/سال/کارکرد + تعدیل مستند وضعیت")

    /** Median actual transaction price per area, multiplied by area and adjustment. */
    fun propertyComparable(medianPricePerArea: Double, area: Double, adjustmentPercent: Double) =
        result(ValuationKind.PROPERTY_COMPARABLE,
            if (valid(medianPricePerArea, area) && adjustmentPercent.isFinite() && adjustmentPercent > -100.0)
                medianPricePerArea * area * (1.0 + adjustmentPercent / 100.0) else null,
            "local currency / property", "میانه معاملات واقعی مشابه هر واحد سطح × مساحت × تعدیل مستند موقعیت/سن/امکانات/سند")

    private fun comparable(kind: ValuationKind, base: Double, adjustmentPercent: Double, unit: String, explanation: String) =
        result(kind, if (valid(base) && adjustmentPercent.isFinite() && adjustmentPercent > -100.0)
            base * (1.0 + adjustmentPercent / 100.0) else null, unit, explanation)

    /** No universal fallback: unsupported assets must remain unvalued until a specialist model exists. */
    fun unsupported(kind: ValuationKind, reason: String) =
        ValuationResult(kind, null, "", false, "مدل تخصصی/داده کافی موجود نیست: $reason")
}
