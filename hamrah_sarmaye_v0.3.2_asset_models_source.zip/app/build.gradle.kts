plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.hamrahsarmaye.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hamrahsarmaye.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 8
        versionName = "0.3.2-dev"
    }
}
