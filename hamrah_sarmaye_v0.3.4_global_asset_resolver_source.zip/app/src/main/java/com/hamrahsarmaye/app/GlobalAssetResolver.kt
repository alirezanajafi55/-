package com.hamrahsarmaye.app

import android.content.SharedPreferences
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Resolves a selected asset to a canonical global benchmark and, when the maker-controlled
 * HTTPS registry is configured, discovers and persists its verified provider endpoint.
 * No guessed endpoint or API key is embedded in the APK.
 */
data class GlobalAssetReference(
    val assetKey: String,
    val benchmarkId: String,
    val displayName: String,
    val providerName: String = "",
    val endpoint: String = "",
    val valuePath: String = "",
    val timestampPath: String = "",
    val currency: String = "USD",
    val unit: String = "",
    val status: String,
    val resolvedAtEpochMs: Long = System.currentTimeMillis()
) {
    val feedReady: Boolean
        get() = endpoint.startsWith("https://", true) && providerName.isNotBlank() &&
            valuePath.isNotBlank() && timestampPath.isNotBlank() && unit.isNotBlank()

    fun toJson() = JSONObject().apply {
        put("assetKey", assetKey); put("benchmarkId", benchmarkId); put("displayName", displayName)
        put("providerName", providerName); put("endpoint", endpoint); put("valuePath", valuePath)
        put("timestampPath", timestampPath); put("currency", currency); put("unit", unit)
        put("status", status); put("resolvedAtEpochMs", resolvedAtEpochMs)
    }

    companion object {
        fun fromJson(o: JSONObject) = GlobalAssetReference(
            assetKey = o.optString("assetKey"), benchmarkId = o.optString("benchmarkId"),
            displayName = o.optString("displayName"), providerName = o.optString("providerName"),
            endpoint = o.optString("endpoint"), valuePath = o.optString("valuePath"),
            timestampPath = o.optString("timestampPath"), currency = o.optString("currency", "USD"),
            unit = o.optString("unit"), status = o.optString("status"),
            resolvedAtEpochMs = o.optLong("resolvedAtEpochMs", 0L)
        )
    }
}

object GlobalAssetResolver {
    /** Maker-controlled registry. Keep blank until a real, authorized registry is deployed. */
    private val registryUrl: String get() = BuildConfig.GLOBAL_ASSET_REGISTRY_URL
    private const val CONNECT_TIMEOUT_MS = 8_000
    private const val READ_TIMEOUT_MS = 8_000
    private const val MAX_REGISTRY_BYTES = 512_000

    data class Candidate(val key: String, val benchmark: String, val label: String, val defaultUnit: String)

    /** Conservative mapping: ambiguous instruments intentionally remain unresolved. */
    fun identify(assetType: String, assetName: String): Candidate? {
        val n = assetName.lowercase(Locale.ROOT)
        val t = assetType.lowercase(Locale.ROOT)
        return when {
            ("طلا" in n || "gold" in n || "gold" in t) -> Candidate("gold.spot", "XAUUSD", "Gold spot", "troy_ounce")
            ("نقره" in n || "silver" in n || "silver" in t) -> Candidate("silver.spot", "XAGUSD", "Silver spot", "troy_ounce")
            ("پلاتین" in n || "platinum" in n || "platinum" in t) -> Candidate("platinum.spot", "XPTUSD", "Platinum spot", "troy_ounce")
            ("پالادیوم" in n || "palladium" in n) -> Candidate("palladium.spot", "XPDUSD", "Palladium spot", "troy_ounce")
            ("یورو" in n || "eur" in n || "euro" in n) -> Candidate("fx.eurusd", "EURUSD", "EUR/USD", "currency_pair")
            ("پوند" in n || "gbp" in n || "pound" in n) -> Candidate("fx.gbpusd", "GBPUSD", "GBP/USD", "currency_pair")
            ("ین ژاپن" in n || "jpy" in n) -> Candidate("fx.usdjpy", "USDJPY", "USD/JPY", "currency_pair")
            ("فرانک سوئیس" in n || "chf" in n) -> Candidate("fx.usdchf", "USDCHF", "USD/CHF", "currency_pair")
            ("نفت برنت" in n || "brent" in n) -> Candidate("energy.brent", "BRENT", "Brent crude", "barrel")
            ("نفت wti" in n || "wti" in n) -> Candidate("energy.wti", "WTI", "WTI crude", "barrel")
            ("بیت کوین" in n || "bitcoin" in n || "btc" in n) -> Candidate("crypto.btcusd", "BTCUSD", "Bitcoin/USD", "coin")
            ("اتریوم" in n || "ethereum" in n || "eth" in n) -> Candidate("crypto.ethusd", "ETHUSD", "Ethereum/USD", "coin")
            // USD by itself is not DXY: DXY is a weighted index, not the USD price.
            else -> null
        }
    }

    /** Runs off the UI thread. Static identity is always resolved; provider endpoint only via registry. */
    fun resolve(assetType: String, assetName: String): GlobalAssetReference? {
        val c = identify(assetType, assetName) ?: return null
        val base = GlobalAssetReference(c.key, c.benchmark, c.label, unit = c.defaultUnit,
            status = "شناسه جهانی شناسایی شد؛ مرجع داده هنوز از فهرست سازنده دریافت نشده است")
        if (registryUrl.isBlank()) return base
        val registry = fetchRegistry() ?: return base.copy(status = "مرجع شناسایی شد؛ فهرست منابع جهانی در دسترس نیست")
        val entries = registry.optJSONArray("assets") ?: return base
        for (i in 0 until entries.length()) {
            val o = entries.optJSONObject(i) ?: continue
            if (!o.optString("assetKey").equals(c.key, true)) continue
            val registryBenchmark = o.optString("benchmarkId")
            if (registryBenchmark.isBlank() || !registryBenchmark.equals(c.benchmark, true)) return base
            val endpoint = o.optString("endpoint")
            val provider = o.optString("providerName")
            val valuePath = o.optString("valuePath")
            val timestampPath = o.optString("timestampPath")
            val currency = o.optString("currency", "USD")
            val unit = o.optString("unit", c.defaultUnit)
            if (!endpoint.startsWith("https://", true) || provider.isBlank() || valuePath.isBlank() ||
                timestampPath.isBlank() || currency.isBlank() || unit.isBlank()) return base
            return base.copy(providerName = provider, endpoint = endpoint, valuePath = valuePath,
                timestampPath = timestampPath, currency = currency, unit = unit,
                status = "مرجع جهانی و اتصال تأمین‌کننده از فهرست سازنده ثبت شد")
        }
        return base
    }

    private fun fetchRegistry(): JSONObject? {
        if (!registryUrl.startsWith("https://", true)) return null
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(registryUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = CONNECT_TIMEOUT_MS; readTimeout = READ_TIMEOUT_MS
                setRequestProperty("Accept", "application/json")
            }
            if (conn.url.protocol != "https" || conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (body.toByteArray(Charsets.UTF_8).size > MAX_REGISTRY_BYTES) return null
            JSONObject(body)
        } catch (_: Exception) { null } finally { conn?.disconnect() }
    }

    fun save(prefs: SharedPreferences, reference: GlobalAssetReference) {
        val key = "global_ref_${reference.assetKey}"
        prefs.edit().putString(key, reference.toJson().toString()).apply()
    }

    fun load(prefs: SharedPreferences, assetType: String, assetName: String): GlobalAssetReference? {
        val candidate = identify(assetType, assetName) ?: return null
        val raw = prefs.getString("global_ref_${candidate.key}", null) ?: return null
        return try { GlobalAssetReference.fromJson(JSONObject(raw)) } catch (_: Exception) { null }
    }

    fun toFeedConfig(reference: GlobalAssetReference): MarketFeedConfig? {
        if (!reference.feedReady) return null
        return MarketFeedConfig(
            id = "global_${reference.assetKey}", endpoint = reference.endpoint,
            valuePath = reference.valuePath, timestampPath = reference.timestampPath,
            currency = reference.currency, unit = reference.unit, providerName = reference.providerName,
            assetKey = reference.assetKey, market = QuoteMarket.GLOBAL
        )
    }
}
