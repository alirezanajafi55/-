package com.hamrahsarmaye.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.NumberFormat
import java.util.Locale

data class AssetItem(val name: String, var amount: Double, var buyPrice: Double, var currentPrice: Double)

class MainActivity : Activity() {
    private val assets = mutableListOf(
        AssetItem("طلای ۱۸ عیار", 2.0, 3_500_000.0, 3_650_000.0),
        AssetItem("دلار آزاد", 300.0, 60_000.0, 61_500.0),
        AssetItem("سکه", 0.0, 0.0, 0.0)
    )
    private lateinit var content: LinearLayout
    private val nf = NumberFormat.getNumberInstance(Locale("fa", "IR"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun money(value: Double) = "${nf.format(value.toLong())} تومان"

    private fun render() {
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 32)
            setBackgroundColor(Color.rgb(247, 248, 250))
        }
        scroll.addView(content)
        setContentView(scroll)

        text("همراه سرمایه", 28, Color.rgb(25, 70, 55), true)
        text("سرمایه مردم، امانت ماست؛ اول محافظت، بعد رشد.", 14, Color.DKGRAY)
        val total = assets.sumOf { it.amount * it.currentPrice }
        val pnl = assets.sumOf { it.amount * (it.currentPrice - it.buyPrice) }
        card {
            text("ارزش تقریبی سبد", 15, Color.DKGRAY)
            text(money(total), 24, Color.rgb(25, 70, 55), true)
            text("سود/زیان تحقق‌نیافته: ${money(pnl)}", 14, if (pnl >= 0) Color.rgb(25,130,80) else Color.RED)
            text("قیمت‌ها نمونه‌ای هستند؛ داده زنده نیستند.", 12, Color.GRAY)
        }
        rowButtons()
        text("دارایی‌های من", 20, Color.BLACK, true)
        assets.forEachIndexed { index, item ->
            card {
                text(item.name, 18, Color.BLACK, true)
                text("مقدار: ${nf.format(item.amount)}", 14, Color.DKGRAY)
                text("قیمت فعلی نمونه: ${money(item.currentPrice)}", 14, Color.DKGRAY)
                val assetPnl = item.amount * (item.currentPrice - item.buyPrice)
                text("سود/زیان: ${money(assetPnl)}", 14, if (assetPnl >= 0) Color.rgb(25,130,80) else Color.RED)
                val buttons = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                buttons.addView(button("ثبت خرید") { tradeDialog(index, true) }, LinearLayout.LayoutParams(0, -2, 1f))
                buttons.addView(button("ثبت فروش") { tradeDialog(index, false) }, LinearLayout.LayoutParams(0, -2, 1f))
                content.addView(buttons)
            }
        }
        text("نسخه نمایشی اولیه — بدون توصیه مالی و بدون قیمت زنده", 12, Color.GRAY)
    }

    private fun rowButtons() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("افزودن دارایی") { addAssetDialog() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("به‌روزرسانی نما") { render() }, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(row)
    }

    private fun addAssetDialog() {
        val name = EditText(this).apply { hint = "نام دارایی" }
        val amount = EditText(this).apply { hint = "مقدار اولیه (اختیاری)"; inputType = 8194 }
        val buy = EditText(this).apply { hint = "قیمت خرید (تومان)"; inputType = 8194 }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 8); addView(name); addView(amount); addView(buy) }
        AlertDialog.Builder(this).setTitle("افزودن دارایی").setView(box)
            .setPositiveButton("افزودن") { _, _ ->
                val a = amount.text.toString().toDoubleOrNull() ?: 0.0
                val p = buy.text.toString().toDoubleOrNull() ?: 0.0
                if (name.text.toString().isNotBlank()) {
                    assets.add(AssetItem(name.text.toString(), a, p, p))
                    render()
                }
            }.setNegativeButton("لغو", null).show()
    }

    private fun tradeDialog(index: Int, isBuy: Boolean) {
        val qty = EditText(this).apply { hint = "مقدار"; inputType = 8194 }
        val price = EditText(this).apply { hint = "قیمت هر واحد (تومان)"; inputType = 8194 }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 8); addView(qty); addView(price) }
        AlertDialog.Builder(this).setTitle(if (isBuy) "ثبت خرید ${assets[index].name}" else "ثبت فروش ${assets[index].name}")
            .setView(box).setPositiveButton("ثبت") { _, _ ->
                val q = qty.text.toString().toDoubleOrNull() ?: 0.0
                val p = price.text.toString().toDoubleOrNull() ?: 0.0
                if (q > 0 && p > 0) {
                    val item = assets[index]
                    if (isBuy) {
                        val newAmount = item.amount + q
                        item.buyPrice = if (newAmount > 0) ((item.amount * item.buyPrice) + (q * p)) / newAmount else p
                        item.amount = newAmount
                    } else if (q <= item.amount) {
                        item.amount -= q
                    } else {
                        Toast.makeText(this, "مقدار فروش از موجودی بیشتر است.", Toast.LENGTH_LONG).show()
                    }
                    item.currentPrice = p
                    render()
                }
            }.setNegativeButton("لغو", null).show()
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) {
        content.addView(TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            gravity = Gravity.RIGHT
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        })
    }

    private fun card(block: LinearLayout.() -> Unit) {
        val parent = content
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundColor(Color.WHITE)
        }
        // Route helper text and nested buttons into this card, not the page root.
        content = box
        try {
            box.block()
        } finally {
            content = parent
        }
        val params = LinearLayout.LayoutParams(-1, -2)
        params.setMargins(0, 12, 0, 12)
        parent.addView(box, params)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }
}
